
export enum Style {
  REALISTIC = 'Realistic',
  ANIME = 'Anime',
  THREED = '3D',
  GLASS = 'Glass',
  WATERCOLOR = 'Watercolor',
  FANTASY = 'Fantasy',
}

export enum Quality {
  STANDARD = 'Standard',
  HD = 'HD',
  ULTRA = 'Ultra',
}
