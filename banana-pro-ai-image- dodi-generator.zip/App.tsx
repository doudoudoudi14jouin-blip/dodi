
import React, { useState, useCallback } from 'react';
import { Style, Quality } from './types';
import { STYLES, QUALITIES } from './constants';
import { generateImage } from './services/geminiService';

const BananaIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-pink-500" viewBox="0 0 24 24" fill="currentColor">
    <path d="M12.9,2.62c-2.83-1.5-6.13-1.04-8.59,1.06c-1.63,1.4-2.58,3.48-2.58,5.63c0,2.83,1.5,5.34,3.76,6.67 C7.93,17.2,10.36,18,12.9,18c0.47,0,0.93-0.05,1.39-0.14c-0.4,1.04-0.61,2.18-0.61,3.37c0,0.93,0.18,1.81,0.5,2.62 c1.35-0.18,2.6-0.89,3.54-1.95c1.4-1.58,2.27-3.66,2.27-5.88c0-3.37-2.09-6.31-5.08-7.39C14.7,7.2,14.07,4.8,12.9,2.62z M12.9,4.06c0.58,1.07,0.89,2.29,0.89,3.54c0,2.37-1.12,4.48-2.88,5.65c-1.1,0.73-2.4,1.14-3.76,1.14 c-1.35,0-2.6-0.4-3.64-1.12c-1.55-1.07-2.48-2.73-2.48-4.52c0-1.55,0.67-3.03,1.79-4.01C4.98,3.04,7.4,2.58,9.7,3.5 c0.77,0.3,1.47,0.75,2.1,1.31C12.35,4.52,12.65,4.29,12.9,4.06z" />
  </svg>
);

const Header = () => (
  <header className="bg-white/80 backdrop-blur-md shadow-sm sticky top-0 z-10">
    <div className="container mx-auto px-4 sm:px-6 lg:px-8">
      <div className="flex items-center justify-between h-16">
        <div className="flex items-center space-x-2">
          <BananaIcon />
          <h1 className="text-xl font-bold text-pink-800">Banana Pro</h1>
        </div>
      </div>
    </div>
  </header>
);

const ImageUploader: React.FC<{
  uploadedImage: string | null;
  onImageChange: (event: React.ChangeEvent<HTMLInputElement>) => void;
  onClearImage: () => void;
}> = ({ uploadedImage, onImageChange, onClearImage }) => (
  <div className="mt-4">
    <label className="block text-sm font-medium text-pink-700 mb-2">Image-to-Image (Optional)</label>
    <div className="mt-1 flex justify-center px-6 pt-5 pb-6 border-2 border-pink-200 border-dashed rounded-md">
      <div className="space-y-1 text-center">
        {uploadedImage ? (
          <div>
            <img src={uploadedImage} alt="Upload preview" className="mx-auto h-24 w-24 object-cover rounded-md" />
            <button onClick={onClearImage} className="mt-2 text-sm text-pink-600 hover:text-pink-800">Remove Image</button>
          </div>
        ) : (
          <>
            <svg className="mx-auto h-12 w-12 text-pink-300" stroke="currentColor" fill="none" viewBox="0 0 48 48" aria-hidden="true">
              <path d="M28 8H12a4 4 0 00-4 4v20m32-12v8m0 0v8a4 4 0 01-4 4H12a4 4 0 01-4-4v-4m32-4l-3.172-3.172a4 4 0 00-5.656 0L28 28M8 32l9.172-9.172a4 4 0 015.656 0L28 28m0 0l4 4m4-24h8m-4-4v8" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
            </svg>
            <div className="flex text-sm text-pink-500">
              <label htmlFor="file-upload" className="relative cursor-pointer bg-white rounded-md font-medium text-pink-600 hover:text-pink-800 focus-within:outline-none focus-within:ring-2 focus-within:ring-offset-2 focus-within:ring-pink-500">
                <span>Upload a file</span>
                <input id="file-upload" name="file-upload" type="file" className="sr-only" onChange={onImageChange} accept="image/*" />
              </label>
              <p className="pl-1">or drag and drop</p>
            </div>
            <p className="text-xs text-pink-400">PNG, JPG, GIF up to 10MB</p>
          </>
        )}
      </div>
    </div>
  </div>
);

const GeneratedImageCard: React.FC<{
  src: string;
  prompt: string;
  onRegenerate: () => void;
}> = ({ src, prompt, onRegenerate }) => {
  const downloadImage = () => {
    const link = document.createElement('a');
    link.href = src;
    link.download = `${prompt.substring(0, 20).replace(/\s/g, '_')}.png`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const shareImage = async () => {
    try {
      const response = await fetch(src);
      const blob = await response.blob();
      const file = new File([blob], 'banana-pro-image.png', { type: 'image/png' });
      if (navigator.share) {
        await navigator.share({
          title: 'AI Generated Image',
          text: `Generated with Banana Pro: ${prompt}`,
          files: [file],
        });
      } else {
        alert('Web Share API is not supported in your browser.');
      }
    } catch (error) {
      console.error('Error sharing image:', error);
      alert('Could not share image.');
    }
  };

  return (
    <div className="bg-white p-2 rounded-lg shadow-md transition-all duration-300 hover:shadow-xl">
      <img src={src} alt={prompt} className="w-full h-auto object-cover rounded-md" />
      <div className="p-2 flex justify-around items-center mt-2">
        <button onClick={downloadImage} className="p-2 rounded-full hover:bg-pink-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-4l-4 4m0 0l-4-4m4 4V4" /></svg>
        </button>
        <button onClick={shareImage} className="p-2 rounded-full hover:bg-pink-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8.684 13.342C8.886 12.938 9 12.482 9 12s-.114-.938-.316-1.342m0 2.684a3 3 0 110-2.684m0 2.684l6.632 3.316m-6.632-6l6.632-3.316m0 0a3 3 0 105.367-2.684 3 3 0 00-5.367 2.684zm0 9.368a3 3 0 105.367 2.684 3 3 0 00-5.367-2.684z" /></svg>
        </button>
        <button onClick={onRegenerate} className="p-2 rounded-full hover:bg-pink-100 transition-colors">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-pink-500" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M4 4v5h5M20 20v-5h-5M4 4l1.5 1.5A9 9 0 0119.5 8.5M20 20l-1.5-1.5A9 9 0 014.5 15.5" /></svg>
        </button>
      </div>
    </div>
  );
};


const LoadingSpinner = () => (
    <div className="flex flex-col items-center justify-center p-8 text-pink-500">
      <svg className="animate-spin -ml-1 mr-3 h-10 w-10 text-pink-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
      </svg>
      <p className="mt-4 text-lg font-medium">Generating your masterpiece...</p>
    </div>
);


export default function App() {
  const [prompt, setPrompt] = useState('');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [base64Image, setBase64Image] = useState<string | null>(null);
  const [selectedStyle, setSelectedStyle] = useState<Style>(Style.REALISTIC);
  const [selectedQuality, setSelectedQuality] = useState<Quality>(Quality.STANDARD);
  const [generatedImages, setGeneratedImages] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleImageChange = (event: React.ChangeEvent<HTMLInputElement>) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      const reader = new FileReader();
      reader.onloadend = () => {
        setUploadedImage(URL.createObjectURL(file));
        setBase64Image(reader.result as string);
      };
      reader.readAsDataURL(file);
    }
  };

  const clearImage = () => {
    setUploadedImage(null);
    setBase64Image(null);
  };
  
  const handleGenerate = useCallback(async () => {
    if (!prompt) {
      setError('Please enter a prompt.');
      return;
    }
    setIsLoading(true);
    setError(null);
    setGeneratedImages([]);

    try {
      const result = await generateImage(prompt, selectedStyle, selectedQuality, base64Image);
      setGeneratedImages([result]);
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'An unexpected error occurred.');
    } finally {
      setIsLoading(false);
    }
  }, [prompt, selectedStyle, selectedQuality, base64Image]);

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow container mx-auto p-4 sm:p-6 lg:p-8">
        <div className="flex flex-col lg:flex-row gap-8">
          {/* Controls Panel */}
          <div className="lg:w-1/3 xl:w-1/4 flex-shrink-0">
            <div className="bg-white p-6 rounded-xl shadow-lg space-y-6">
              <div>
                <label htmlFor="prompt" className="block text-lg font-semibold text-pink-800">Your Prompt</label>
                <textarea
                  id="prompt"
                  rows={4}
                  className="mt-2 w-full p-3 border border-pink-200 rounded-lg focus:ring-pink-500 focus:border-pink-500 transition"
                  placeholder="e.g., A cute cat wearing a tiny party hat"
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                />
              </div>

              <ImageUploader uploadedImage={uploadedImage} onImageChange={handleImageChange} onClearImage={clearImage} />

              <div>
                <h3 className="text-md font-medium text-pink-700">Style</h3>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 mt-2">
                  {STYLES.map((style) => (
                    <button key={style} onClick={() => setSelectedStyle(style)} className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedStyle === style ? 'bg-pink-500 text-white shadow' : 'bg-pink-100 text-pink-700 hover:bg-pink-200'}`}>
                      {style}
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <h3 className="text-md font-medium text-pink-700">Quality</h3>
                <div className="grid grid-cols-3 gap-2 mt-2">
                  {QUALITIES.map((quality) => (
                    <button key={quality} onClick={() => setSelectedQuality(quality)} className={`px-4 py-2 text-sm font-medium rounded-md transition-all ${selectedQuality === quality ? 'bg-pink-500 text-white shadow' : 'bg-pink-100 text-pink-700 hover:bg-pink-200'}`}>
                      {quality}
                    </button>
                  ))}
                </div>
              </div>
              
              <button
                onClick={handleGenerate}
                disabled={isLoading}
                className="w-full text-white font-bold py-3 px-4 rounded-lg bg-gradient-to-r from-pink-400 to-pink-500 hover:from-pink-500 hover:to-pink-600 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-pink-500 disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-300 transform hover:scale-105 shadow-lg"
              >
                {isLoading ? 'Generating...' : 'Generate'}
              </button>

              {error && <p className="text-sm text-red-500 mt-2 text-center">{error}</p>}
            </div>
          </div>

          {/* Image Display */}
          <div className="lg:w-2/3 xl:w-3/4">
            <div className="bg-white/50 p-6 rounded-xl shadow-lg min-h-[300px] flex items-center justify-center">
              {isLoading && <LoadingSpinner />}
              {!isLoading && generatedImages.length === 0 && (
                 <div className="text-center text-pink-400">
                    <BananaIcon />
                    <p className="mt-2 text-lg">Your generated images will appear here</p>
                    <p className="text-sm">Let's create something beautiful!</p>
                 </div>
              )}
              {!isLoading && generatedImages.length > 0 && (
                <div className="grid grid-cols-1 md:grid-cols-1 gap-4 w-full">
                  {generatedImages.map((src, index) => (
                    <GeneratedImageCard key={index} src={src} prompt={prompt} onRegenerate={handleGenerate} />
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
