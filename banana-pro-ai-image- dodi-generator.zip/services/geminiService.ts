
import { GoogleGenAI } from "@google/genai";
import { Style, Quality } from '../types';

if (!process.env.API_KEY) {
    // In a real app, you'd want to handle this more gracefully.
    // For this environment, we assume the key is set.
    console.warn("API_KEY environment variable not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY! });

// Helper to convert data URL to part
const fileToPart = (base64Data: string) => {
    const match = base64Data.match(/^data:(.+);base64,(.+)$/);
    if (!match) {
        throw new Error('Invalid base64 string');
    }
    const [_, mimeType, data] = match;
    return {
        inlineData: {
            mimeType,
            data,
        },
    };
};

export const generateImage = async (
    prompt: string,
    style: Style,
    quality: Quality,
    base64Image: string | null
): Promise<string> => {
    
    let modelName: string;
    let imageSize: '1K' | '2K' | '4K' = '1K';

    switch (quality) {
        case Quality.HD:
            modelName = 'gemini-3-pro-image-preview';
            imageSize = '1K';
            break;
        case Quality.ULTRA:
            modelName = 'gemini-3-pro-image-preview';
            imageSize = '2K';
            break;
        case Quality.STANDARD:
        default:
            modelName = 'gemini-2.5-flash-image';
            break;
    }

    const fullPrompt = `${style} style: ${prompt}`;
    
    const parts: any[] = [];
    if (base64Image) {
        parts.push(fileToPart(base64Image));
    }
    parts.push({ text: fullPrompt });

    const contents = { parts };

    const config = {
        imageConfig: {
            aspectRatio: '1:1' as const,
            ...(modelName === 'gemini-3-pro-image-preview' && { imageSize }),
        },
    };

    try {
        const response = await ai.models.generateContent({
            model: modelName,
            contents,
            config,
        });

        for (const part of response.candidates?.[0]?.content?.parts || []) {
            if (part.inlineData) {
                const base64EncodeString: string = part.inlineData.data;
                const imageUrl = `data:${part.inlineData.mimeType};base64,${base64EncodeString}`;
                return imageUrl;
            }
        }

        throw new Error('No image was generated. The model may have refused the prompt.');

    } catch (error: any) {
        console.error("Gemini API Error:", error);
        throw new Error(error.message || 'Failed to generate image due to an API error.');
    }
};
