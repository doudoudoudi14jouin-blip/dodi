
import { Style, Quality } from './types';

export const STYLES = Object.values(Style);
export const QUALITIES = Object.values(Quality);
